
-- Create the exceptional channels table 

CREATE TABLE exceptionalChannels (
        id serial,
        name text unique not null
);

